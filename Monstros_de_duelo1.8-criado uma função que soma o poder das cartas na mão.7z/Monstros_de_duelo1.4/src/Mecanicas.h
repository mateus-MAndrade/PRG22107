/*
 * Mecanicas.h
 *
 *  Created on: 4 de jul de 2022
 *      Author: Aluno
 */

#ifndef MECANICAS_H_
#define MECANICAS_H_

#include "Deck.h"
#include "Jogador.h"


class Mecanicas {
public:
	Mecanicas();
	//void menu(Jogador * playerA,Jogador * playerB,Deck * baralhoA,Deck * baralhoB,Mecanicas * obj7);
	void menu(Jogador * playerA,Jogador * playerB,Deck * baralhoA,Deck * baralhoB);

	void duelo(Jogador * playerA,Jogador * playerB,int A,int B);
	void criaBaralho(Deck * baralho);
	void limpa();
	//std::vector<std::pair<std::string, std::vector<int>>> read_csv(std::string lista_de_monstros_csv_,Deck * baralhoA,Deck * baralhoB);
	virtual ~Mecanicas();
};

#endif /* MECANICAS_H_ */
