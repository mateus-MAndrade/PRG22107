/*
 * Mecanicas.cpp
 *
 *  Created on: 4 de jul de 2022
 *      Author: Aluno
 */

#include <stdio.h>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <fstream>
#include <vector>
#include <utility>

#include "Mecanicas.h"
#include "Jogador.h"
#include "Deck.h"

Mecanicas::Mecanicas()
{

	// TODO Auto-generated constructor stub

}


Mecanicas::~Mecanicas() {
	// TODO Auto-generated destructor stub
}

void Mecanicas::menu(Jogador * playerA,Jogador * playerB,Deck *baralhoA,Deck*baralhoB)
{
	int m=0,n=0,j=1,i=0,b=0,p,q,t=0,v=0;
	char l;
	Carta * temp;
	//Deck * atacou;
	Jogador playerTemp;
	cout << "It's time to duel!" << endl;
	//Inicio do jogo
	playerA->compraCartas(baralhoA, 4);
	playerB->compraCartas(baralhoB, 4);
	//Jogador 1 começa o jogo
	while(1)
	{
		cout << "Escolha o modo de jogo:"
				<<endl<<"Digite 1 para jogar contra outro jogador;"
				<<endl<<"Digite 2 para jogar contra a CPU. "<<endl;
		cin >>  m;
		fflush(stdin);
		switch(m)
		{
		case 1:
		{
			cout<<endl<<endl<<endl<<endl;
			cout << "Voce escolheu jogar contra outro jogador; " << endl;
			while(1)
			{
				fflush(stdin);
				cout <<"Turno do jogador: " <<j<< endl
						<<"voce possui: "<< * playerA->retornaVida()<<" pontos de vida"<<endl;


				if(playerA->size_mao()!=4&& b==0)
				{
					playerA->compraCartas(baralhoA, 1);
					b++;
				}
				cout << "Escolha uma opcao:"
						<<endl<<"Digite <1> para mostrar as cartas na mao novamente;"
						<<endl<<"Digite <2> para colocar um monstro em campo;"
						<<endl<<"Digite <3> para visualizar o campo;"
						<<endl<<"Digite <4> para ir para a fase de batalha;"
						<<endl<<"Digite <5> para finalizar o seu turno."
						<<endl;
				cin >>  n;
				cout << "voce escolheu a opcao: " <<n<< endl;

				switch(n)
				{
				case 1:
					playerA->printMao();
					playerA->somamao();
					playerA->printsomamao();
					break;
				case 2:
				{
					fflush(stdin);
					if(playerA->size_campo()<5)
					{
						if(playerA->size_mao()==4)
						{

							playerA->adicionaCampo(1);
							b++;
							break;
						}
						else
						{
							cout << "Voce so pode colocar um monstro em campo por turno!"<< endl;
							break;
						}
					}
					else
					{
						cout << "Voce ja possui 5 monstros em campo!"<< endl;
						break;
					}
				}
				case 3:
				{
					if(playerA->size_campo()<5)
					{
						cout << "Monstros do jogador 1:" << endl;
						playerA->printCampo();
						cout << endl;
						cout << "Monstros do jogador 2:" << endl;
						playerB->printCampo();
						cout << endl;
						break;
					}
					else
					{
						cout << "Voce possui 5 monstros em campo!" << endl;
						break;
					}
				}
				case 4:
				{
					if(i==0 && t>0)
					{
						if (playerA->size_campo()!=0)
						{
							v=playerB->size_campo();
							cout << "jogador 2 possui: " << v << " cartas em campo"<<endl;
							while(v!=0)
							{
								i=1;
								cout << "Monstros no campo do jogador 1:" << endl;
								playerA->printCampo();
								cout    << endl;
								cout    << "Escolha um de seus monstros para batalhar;"
										<<endl<<"Digite <1> para selecionar monstro 1; "
										<<endl<<"Digite <2> para selecionar monstro 2; "
										<<endl<<"Digite <3> para selecionar monstro 3; "
										<<endl<<"Digite <4> para selecionar monstro 4; "
										<<endl<<"Digite <5> para selecionar monstro 5; "
										<<endl<<"Digite <0> para sair da batalha. "
										<<endl;
								fflush(stdin);
								cin >>  p;
								if(p==0)
									break;
								cout << "Monstros no campo do jogador 2:" << endl;
								playerB->printCampo();
								cout    << endl;
								cout    << "Escolha um monstro do seu oponente para batalhar;"
										<<endl<<"Digite <1> para selecionar monstro 1; "
										<<endl<<"Digite <2> para selecionar monstro 2; "
										<<endl<<"Digite <3> para selecionar monstro 3; "
										<<endl<<"Digite <4> para selecionar monstro 4; "
										<<endl<<"Digite <0> para sair da batalha. "
										<<endl;
								fflush(stdin);
								cin >>  q;
								if(q==0)
								{
									break;
								}
								duelo(playerA, playerB, p, q);

								if(playerB->size_campo()!=0)
								{cout << "Deseja continuar batalhando?"
									<<" Digite 'S'para sair ou 'N' para continuar na fase da batalha"
									<<endl;
								cin >> l;
								if(l=='s'||l=='S' )
								{
									break;
								}
								playerB->printCampo();}
								cout <<"Jogador 1 possui: "<<*playerA->retornaVida() <<" Pontos de vida "<< endl
										<<"Jogador 2 possui: "<<*playerB->retornaVida() <<" Pontos de vida "<< endl;
								v--;
							}
							//break;
							{
								for(i=0;i<playerA->size_campo();i++)
								{
									temp=playerA->retornaCampo()->remove(i);
									playerB->modificaVida(temp->retorna_poder()*-1);
									cout <<"Jogador 2 foi atacado pelo monstro: "<< temp->retorna_nome()
									 						 <<" e tomou "<<&temp->retorna_poder <<" de dano e esta com :"<<*playerB->retornaVida()
																 <<" Pontos de vida "<< endl;
									playerA->retornaCampo()->add(temp);
								}
								break;
							}
						}
						else
						{
							cout <<"Voce nao possui monstros em campo para batalhar! "<<endl;
							break;
						}
					}
					else
					{
						cout <<"Voce nao pode batalhar no turno 1! "<<endl;
						break;}
				}
				case 5:
					i=0;
					b=0;
					t++;
					playerTemp=*playerA;
					*playerA=*playerB;
					*playerB=playerTemp;
					if(j==1)
						j=2;
					else
						j=1;
				}
			}
		}
		break;
		case 2:
		{
			cout <<"Funcao nao implementada. "<<endl;

			break;
		}
		}
	}
}


void Mecanicas::duelo(Jogador* p1,Jogador* p2,int A,int B)
{
	int select,pwA,pwB;
	select = A;
	Carta * Monstro_A = p1->retornaCampo()->remove(select-1);
	cout << "Voce selecionou a carta " <<*Monstro_A << endl;
	select = B;
	Carta * Monstro_B = p2->retornaCampo()->remove(select-1);
	cout << "Voce selecionou a carta " <<*Monstro_B << endl;
	//Monstro_A->mostra_nome();
	cout <<  endl;
	//Monstro_B->mostra_nome();
	cout <<  endl;
	if (Monstro_A->retorna_poder() > Monstro_B->retorna_poder())
	{
		cout << "Monstro A Wins!" << endl;
		cout << "O monstro " <<Monstro_A->retorna_nome()<<" derrotou o monstro "<<Monstro_B->retorna_nome() << endl;

		p1->retornaCampo()->add(Monstro_A);
		p2->retornacemiterio()->add(Monstro_B);
		pwA=Monstro_A->retorna_poder();
		pwB=Monstro_B->retorna_poder();
		p2->modificaVida(-(pwA-pwB));
		cout << "Jogador 2 tomou " <<pwA-pwB<< " de dano e esta com "<<*p2->retornaVida() <<" de vida!"<< endl;
	}
	else if((Monstro_A->retorna_poder() < Monstro_B->retorna_poder()))
	{
		cout << "Monstro B Wins!" << endl;
		cout << "O monstro " <<Monstro_B->retorna_nome()<<"derrotou o monstro "<<Monstro_A->retorna_nome() << endl;
		p2->retornaCampo()->add(Monstro_A);
		p1->retornacemiterio()->add(Monstro_B);
		pwA=Monstro_A->retorna_poder();
		pwB=Monstro_B->retorna_poder();
		p1->modificaVida(-(pwB-pwA));
		cout << "Jogador 1 tomou " <<pwB-pwA<< " de dano e esta com "<<*p1->retornaVida() <<" de vida!"<< endl;
	}/*
	else if(p2->retornaCampo()==0)
	{
		cout << "entrou no else if " <<endl;

		for(int i=0;i<p1->size_campo();i++)
		{
			cout << "entrou no laço for " <<endl;
			Carta * temp=p1->retornaCampo()->remove(i-1);
			p2->modificaVida(temp->retorna_poder());
			cout <<"Jogador 2 foi atacado pelo monstro: "<< temp->retorna_nome()
											    						 <<" e tomou "<<&temp->retorna_poder <<"de dano e esta com :"<<*p2->retornaVida()
																		 <<" Pontos de vida "<< endl;
			p1->retornaCampo()->add(temp);
		}
	}*/
	else
	{
		cout << "O monstro " <<Monstro_A->retorna_nome()<<" possui o mesmo poder que o monstro "<<Monstro_B->retorna_nome() << endl;
		p1->retornacemiterio()->add(Monstro_A);
		p2->retornacemiterio()->add(Monstro_B);
		p1->retornaCampo()->remove()->retorna_poder();
	}

}

void Mecanicas::limpa()
{
	system("cls");
}

/*
void criaBaralho(Deck * baralho)
{
	char letra,c;
	int linhas;
	 while(fread (&c, sizeof(char), 1, fp))
	        {
	            if(c == letra)
	             {
	                linhas++;
	            }
	        }
	//retorno = fread(&Tab, sizeof(struct Agenda), 1, fp);
	    //fread(&estacao, sizeof(struct monitora), 1, fp);
	         for(i=0;i<=linhas;i++)
	         {
	         fscanf(fp,"%s%d%f%s",baralho->add(new Carta));
	     }

}

std::vector<std::pair<std::string, std::vector<int>>> read_csv(std::string lista_de_monstros_csv_,Deck * baralhoA,Deck * baralhoB){
	 // Reads a CSV file into a vector of <string, vector<int>> pairs where
	    // each pair represents <column name, column values>

	    // Create a vector of <string, int vector> pairs to store the result
	    std::vector<std::pair<std::string, std::vector<int>>> result;

	    // Create an input filestream
	    std::ifstream myFile(lista_de_monstros_csv_);

	    // Make sure the file is open
	    if(!myFile.is_open()) throw std::runtime_error("Could not open file");

	    // Helper vars
	    std::string line, colname;
	    int val;

	    // Read the column names
	    if(myFile.good())
	    {
	        // Extract the first line in the file
	        std::getline(myFile, line);

	        // Create a stringstream from line
	        std::stringstream ss(line);

	        // Extract each column name
	        while(std::getline(ss, colname, ',')){

	            // Initialize and add <colname, int vector> pairs to result
	            result.push_back({colname, std::vector<int> {}});
	        }
	    }

	    // Read data, line by line
	    while(std::getline(myFile, line))
	    {
	        // Create a stringstream of the current line
	        std::stringstream ss(line);

	        // Keep track of the current column index
	        int colIdx = 0;

	        // Extract each integer
	        while(ss >> val){

	            // Add the current integer to the 'colIdx' column's values vector
	            result.at(colIdx).second.push_back();
	            // If the next token is a comma, ignore it and move on
	            if(ss.peek() == ',') ss.ignore();

	            // Increment the column index
	            colIdx++;
	        }
	    }

	    // Close file
	    myFile.close();

	    return result;
	}
 */
